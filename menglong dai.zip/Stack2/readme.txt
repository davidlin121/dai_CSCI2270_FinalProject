stack��

	1.variable��
		base��stack bottom
		top��stack top
		stackSize��stack size
		
	2.method��
		InitStack��start a new stack
		GetTop��the top stack
		Push��push a new element to stack
		Pop��delete one element stack
		DestroyStack��delete stack
		ClearStack��clear stack
		GetStackLength��the length of stack
		isStackEmpty��determine the stack is empry or not
		StackTraverse��read stack element
		
application��
	
	1��BusStationSimulation
	 a single entre and exit bus, first pop in to the bus, then came out of bus, can count how many people in the bus.

Dependencies
i finished it by myself
System	Requirements
windows
Group	Members
menglong dai
Open issues/bugs
some version of codeblock doesn't know what is malloc