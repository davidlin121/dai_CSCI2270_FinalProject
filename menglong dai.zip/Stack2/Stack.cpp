#include <iostream>
using namespace std;
#include "stdlib.h"
#include "Stack.h"

Stack::Stack()
{
}

Stack::~Stack()
{
}

//��ʼ��ջ
Status Stack::InitStack(Stack &stack)
{
	stack.base = (SElemType *)malloc(STACK_INIT_SIZE*sizeof(SElemType));
	if (!stack.base)
	{
		exit(ERROR);
	}

	stack.top = stack.base;
	stack.stackSize = STACK_INIT_SIZE;
	return OK;
}

//��ȡջ��Ԫ��
Status Stack::GetTop(Stack stack, SElemType &elem)
{
	if (isStackEmpty(stack))
	{
		return ERROR;
	}

	elem = *(stack.top - 1);

	return OK;
}

//����Ԫ��elemΪ�µ�ջ��Ԫ��
Status Stack::Push(Stack &stack, SElemType elem)
{
	if (stack.top - stack.base >= stack.stackSize)
	{
		stack.base = (SElemType *)realloc(stack.base,
			(stack.stackSize + STACK_INCREMENT)*sizeof(SElemType));

		if (!stack.base)
		{
			exit(ERROR);
		}

		stack.top = stack.base + stack.stackSize;
		stack.stackSize += STACK_INCREMENT;
	}

	*stack.top = elem;
	stack.top++;

	return OK;
}

//ɾ��ջ��Ԫ��
Status Stack::Pop(Stack &stack, SElemType &elem)
{
	if (isStackEmpty(stack))
	{
		return ERROR;
	}

	elem = *(stack.top - 1);
	stack.top--;

	return OK;
}

//����ջ
Status Stack::DestroyStack(Stack &stack)
{
	free(stack.base);
	stack.base = stack.top = NULL;
	stack.stackSize = 0;
	return OK;
}

//���ջ
Status Stack::ClearStack(Stack &stack)
{
	stack.top = stack.base;
	return OK;
}

//��ȡջ���������ݵĳ���
int Stack::GetStackLength(Stack &stack)
{
	return stack.top - stack.base;
}

//�ж�ջ�Ƿ�Ϊ��ջ
Status Stack::isStackEmpty(Stack stack)
{
	if (stack.top == stack.base)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

//����ջ�е�ÿһ��Ԫ��
Status Stack::StackTraverse(Stack stack)
{
	SElemType *ptr;

	ptr = stack.top;
	while (ptr != stack.base)
	{#include "stdlib.h"
		cout << *(ptr-1) << " ";
		ptr--;
	}

	return OK;
}
