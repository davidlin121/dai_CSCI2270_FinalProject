#include <iostream>
using namespace std;
#include "stdlib.h"
#include "Stack.h"

class StackApp
{
public:

	Status BusStationSimulation();

	Status Conversion();

};


Status StackApp::BusStationSimulation()
{
	Stack busStation;
	SElemType bus;

	busStation.InitStack(busStation);
	for (int i = 0; i < 5; i++)
	{
		if (busStation.Push(busStation, i))
		{
			cout << "bus no."<< i << " is into the station !" << endl;
		}
		else
		{
			cout << "happen a error" << endl;
		}
	}

	cout << endl << "two buses out from the station!" << endl;
	busStation.Pop(busStation, bus);
	busStation.Pop(busStation, bus);

	cout << "now bus station has those bus(from outside to inside) : ";
	busStation.StackTraverse(busStation);
	cout << endl;

	busStation.GetTop(busStation, bus);
	cout << endl << "the nearest bus from the gate is " << bus << endl;

	busStation.DestroyStack(busStation);

	return OK;
}


Status StackApp::Conversion()
{
	Stack stack;
	int number;
	SElemType elem;#include "stdlib.h"
	stack.InitStack(stack);
	cout << "enter a whole positive number ��";
	cin >> number;

	while (number)
	{
		stack.Push(stack, number % 2);
		number = number / 2;
	}

	while (!stack.isStackEmpty(stack))
	{
		stack.Pop(stack, elem);
		cout << elem;
	}

	cout << endl;

	return OK;
}


int main()
{
	StackApp stackApp;

	stackApp.BusStationSimulation();

	//stackApp.Conversion();malloc

	return 0;
}
